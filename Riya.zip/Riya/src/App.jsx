import './App.css'
import Profile from './pages/Profile'

function App() {
  return (
    <>
      <Profile />
    </>
  )
}

export default App
