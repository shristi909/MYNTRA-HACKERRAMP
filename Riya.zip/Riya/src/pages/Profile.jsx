import React from "react";
import controlIcon from "../assets/settings.png";
import addIcon from "../assets/more.png";
import "./Profile.css";
import blackSaree from "../assets/blackSaree.png";
import summerWear from "../assets/summer.png";
import ambani from "../assets/ambani.jpg";
import pen from "../assets/pen.png";

function Profile() {
  return (
    <section className="container">
      <div className="infoContainer">
        <img
          src="https://images.unsplash.com/photo-1613005798967-632017e477c8?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8Z2lybHxlbnwwfHwwfHx8MA%3D%3D"
          alt="girl image"
        />
        <h1>Ananya</h1>
        <p>riya@9012</p>
        <h3>500 following</h3>
      </div>

      <div className="btnContainer">
        <button className="btn profileBtn">Share</button>
        <button className="btn profileBtn">Edit Profile</button>
      </div>

      <div className="optContainer">
        <button className="btn option">
          <img src={controlIcon} alt="" />
        </button>
        <button className="btn option">
          <img src={addIcon} alt="" />
        </button>
      </div>

      <div className="gridContainer">
        <div className="collection">
          <img
            src={blackSaree}
            alt="grid"
          />
          <p>Sareeeeeee</p>
          <div className="edit">
            <img src={pen} alt="edit" />
          </div>
        </div>
        <div className="collection">
          <img
            src={summerWear}
            alt="grid"
          />
          <p>Summer Collection</p>
          <div className="edit">
            <img src={pen} alt="edit" />
          </div>
        </div>
        <div className="collection">
          <img
            src={ambani}
            alt="grid"
          />
          <p>Bridal Collection</p>
          <div className="edit">
            <img src={pen} alt="edit" />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Profile;
