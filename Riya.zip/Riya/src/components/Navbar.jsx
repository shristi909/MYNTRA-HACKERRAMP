import React from "react";
import "./Navbar.css"; // Import the CSS file

function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <a href="https://flowbite.com" className="navbar-link">
          <span className="navbar-brand">
            Fwd<i className="bx bxs-chevron-down"></i>
          </span>
          <div className="navbar-become-insider">
            Become <br /> Insider
            <div className="navbar-build-my-fit">
              Build <br /> My Fit
            </div>
          </div>
        </a>
        <div className="flex items-center col-span-4 gap-4">
          <form className="search-form">
            <label htmlFor="default-search" className="search-label">
              Search
            </label>
            <div className="search-wrapper">
              <div className="search-icon">
                <img
                  className="w-8 h-8 rounded-full"
                  src="./assets/img/ai_icon.png"
                  alt=""
                />
              </div>
              <input
                type="search"
                id="default-search"
                className="search-input"
                placeholder="Search"
                required
              />
              <button type="submit" className="search-button">
                <i className="bx bxs-color"></i>
              </button>
              <button type="submit" className="search-microphone">
                <i className="bx bxs-microphone"></i>
              </button>
            </div>
          </form>
          <div className="navbar-icons" id="mobile-menu-2">
            <i className="bx bxs-bell"></i>
            <i className="bx bxs-cart"></i>
            <i className="bx bxs-user-circle"></i>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
